

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    <h4>Daftar Soal</h4>
                    
                </div>

                <div class="card-body">
                    <ul>
                        <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <li>[ <?php echo e($question->question); ?> - <?php echo e($question->level); ?> ] <a href="<?php echo e(route('questions.show', $question->id)); ?>">detail</a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>

                    <br>
                    <p class="message"><?php echo e(session('message')); ?></p>
                    <p class="message message-delete"><?php echo e(session('message-delete')); ?></p>
                    <br><br>
                    <button>
                        <a href="<?php echo e(route('questions.add')); ?>">Tambah soal</a>
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\PRAKTIKUM\prak WEB F\quiz game\guess-the-word-quiz\backend\resources\views/questions/index.blade.php ENDPATH**/ ?>