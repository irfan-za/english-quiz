

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Soal Id ke-<?php echo e($question->id); ?></div>

                <div class="card-body">
                  <table>
                    <tr>
                      <td>kata kunci </td>
                      <td> : </td>
                      <td><?php echo e($question->question); ?></td>
                    </tr>
                    <tr>
                      <td>level </td>
                      <td> : </td>
                      <td><?php echo e($question->level); ?></td>
                    </tr>
                    <tr>
                      <td>link audio </td>
                      <td> : </td>
                      <td><a href="<?php echo e($question->sound_url); ?>" target="blank" ><?php echo e($question->sound_url); ?></a></td>
                    </tr>
                    <tr>
                      <td>hint </td>
                      <td> : </td>
                      <td><?php echo e($question->hint); ?></td>
                    </tr>
                  </table>

                  <br><br>
                  <form action="<?php echo e(route('questions.destroy', $question->id )); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit">Hapus</button>
                  </form>
                  <br>
                  <a href="<?php echo e(route('questions.index')); ?>">kembali ke daftar soal</a>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\kuliah\PRAKTIKUM\prak WEB F\quiz game\guess-the-word-quiz\backend\resources\views/questions/show.blade.php ENDPATH**/ ?>